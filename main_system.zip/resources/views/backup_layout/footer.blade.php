<footer class="main-footer">
    <div class="footer-left">
      Copyright &copy; 2021 <div class="bullet"></div> Powered By <a href="https://siris-dev.com/">Siris</a>
    </div>
    <div class="footer-right">
      2.3.0
    </div>
  </footer>