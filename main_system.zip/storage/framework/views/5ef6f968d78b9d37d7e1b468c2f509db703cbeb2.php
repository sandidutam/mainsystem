<?php $__env->startSection('title'); ?>
    Presensi Masuk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Check In
<?php $__env->stopSection(); ?>

<?php $__env->startSection('presensi.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('indexin.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="section">
        <div class="section-header">
            <h1>Check In</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('presensi.history')); ?>">Menu Presensi</a></div>
                <div class="breadcrumb-item active"><a href="<?php echo e(route('presensi.indexin')); ?>">Presensi Masuk</a></div>
                <div class="breadcrumb-item">Check In</div>
            </div>
        </div>

        <div class="section-body">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <a href="<?php echo e(route('presensi.indexin')); ?>" class="btn btn-primary ">
                    <span class="icon">
                        <i class="fas fa-chevron-left mr-2"></i>
                    </span>
                    <span class="text">Kembali</span>
                </a>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4>Menu Presensi Masuk</h4>
                </div>

                <div class="card-body">
                    <?php if(session('notifikasi_sukses')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <i class="fa fa-check-circle"></i>
                        <?php echo e(session('notifikasi_sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session('notifikasi_gagal')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <i class="fa fa-exclamation-triangle"></i>
                        <?php echo e(session('notifikasi_gagal')); ?>

                    </div>
                    <?php endif; ?>

                    <?php echo Form::model($data_pegawai ,['route'=>['presensi.store', $data_pegawai->id ], 'method'=>'POST']); ?>


                    

                    <div class="row">
                        <div class="col-12 col-md-6 col-lg-6">
                            <h1 class="text-center text-success">Tanggal</h1>
                            <h3 class="text-center"><?php echo e(date('D, d-M-Y', strtotime($today))); ?></h3>
                            <h1 class="text-center text-success" style="margin-top: 40px">Jam</h1>
                            <h3 id="currentTime"></h3>

                            <div class="row mb-2 justify-content-center invisible">
                                <div class="col-12 col-md-6 col-lg-6 ">
                                    <div class="form-group <?php echo e($errors->has('id') ? 'has-error' : ''); ?>">
                                        <label for="id" class="form-label"> ID : </label>
                                        <?php echo Form::text('id', null, ['class'=>'form-control','id'=>'id','name'=>'id','readonly']); ?>

                                        <?php if($errors->has('id')): ?>
                                            <span class="help-block text-danger"><?php echo e($errors->first('id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6">
                            <div class="row mb-2 justify-content-center">
                                <div class="col-12 col-md-6 col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('nomor_pegawai') ? 'has-error' : ''); ?>">
                                        <label for="nomor_pegawai" class="form-label"> Nomor Pegawai : </label>
                                        <?php echo Form::text('nomor_pegawai', null, ['class'=>'form-control','id'=>'nomor_pegawai','name'=>'nomor_pegawai','readonly']); ?>

                                        <?php if($errors->has('nomor_pegawai')): ?>
                                            <span class="help-block text-danger"><?php echo e($errors->first('nomor_pegawai')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2 justify-content-center">
                                <div class="col-12 col-md-6 col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('nama_lengkap') ? 'has-error' : ''); ?>">
                                        <label for="nama_lengkap" class="form-label"> Nama Lengkap : </label>
                                        <?php echo Form::text('nama_lengkap', $data_pegawai->nama_lengkap(), ['class'=>'form-control','id'=>'nama_lengkap','name'=>'nama_lengkap','readonly']); ?>

                                        <?php if($errors->has('nama_lengkap')): ?>
                                            <span class="help-block text-danger"><?php echo e($errors->first('nama_lengkap')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2 justify-content-center">
                                <div class="col-12 col-md-6 col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('jabatan') ? 'has-error' : ''); ?>">
                                        <label for="jabatan" class="form-label"> Jabatan : </label>
                                        <?php echo Form::text('jabatan', null, ['class'=>'form-control','id'=>'jabatan','name'=>'jabatan','readonly']); ?>

                                        <?php if($errors->has('jabatan')): ?>
                                            <span class="help-block text-danger"><?php echo e($errors->first('jabatan')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3 justify-content-center">
                                <div class="col-12 col-md-6 col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('sektor_area') ? 'has-error' : ''); ?>">
                                        <label for="sektor_area" class="form-label"> Sektor : </label>
                                        <?php echo Form::text('sektor_area', null, ['class'=>'form-control','id'=>'sektor_area','name'=>'sektor_area','readonly']); ?>

                                        <?php if($errors->has('sektor_area')): ?>
                                            <span class="help-block text-danger"><?php echo e($errors->first('sektor_area')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2 justify-content-center">
                                <div class="col-12 col-md-6 col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('keterangan') ? 'has-error' : ''); ?>">
                                        <label for="keterangan" class="mb-2"> Keterangan : </label>
                                        <select name="keterangan" class="form-control" id="keterangan" >
                                        <option selected="true" style='display: none' value="">Pilih</option>
                                        <option value="Bolos" <?php echo e((old('keterangan')=='Bolos')? 'selected' :''); ?>>Tidak Hadir / Bolos</option>
                                        <option value="Cuti" <?php echo e((old('keterangan')=='Cuti')? 'selected' :''); ?>>Cuti</option>
                                        <option value="Izin" <?php echo e((old('keterangan')=='Izin')? 'selected' :''); ?>>Izin</option>
                                        <option value="Sakit" <?php echo e((old('keterangan')=='Sakit')? 'selected' :''); ?>>Sakit</option>
                                        </select>
                                        <div class="div">
                                            <?php if($errors->has('keterangan')): ?>
                                                <span class="help-block text-danger"><?php echo e($errors->first('keterangan')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="div">
                                            <small id="helpId" class="fst-italic text-muted"> <span class=" fw-bold text-danger">Perhatian!</span> Keterangan diisi apabila pegawai tidak masuk kerja</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-2 justify-content-center">

                                <button type="submit" class="btn btn-success mx-3 my-3" name="btn_masuk" style="width: 10rem" value="btn_masuk" >PRESENSI MASUK</button>

                                <button type="submit" class="btn btn-danger mx-3 my-3" name="btn_absen" style="width: 10rem" value="btn_absen">ABSEN</button>

                            </div>

                        </div>
                    </div>



                    

                <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </section>

    <script type="text/javascript">
        $('.datepicker').datepicker({
           format: 'yyyy-mm-dd'
         });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/presensi/checkin.blade.php ENDPATH**/ ?>