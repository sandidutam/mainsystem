<h1>Tabel Neraca</h1>

<table class="table" style="border: 1px solid black; border-collapse:collapse;">
    <thead style="border: 1px solid black;">
        <tr style="background-color: black; color: white;">
            <th style="width: 80px; font-size: 12px;">Nomor Transaksi</th>
            <th style="width: 80px; font-size: 12px;">Transaksi</th>
            <th style="width: 80px; font-size: 12px;">Deskripsi</th>
            <th style="width: 100px; font-size: 12px;">Debit (Rp)</th>
            <th style="width: 100px; font-size: 12px;">Kredit (Rp)</th>
            <th style="width: 100px; font-size: 12px;">Tanggal</th>
        </tr>
    </thead>
    <tbody style="border: 1px solid black;">
        <?php $__currentLoopData = $neraca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="font-size: 10px; border: 1px solid black"><?php echo e($n->nomor_akun); ?></td>
            <td style="width: 80px;font-size: 10px; border: 1px solid black"><?php echo e($n->akun); ?></td>
            <td style="width: 80px; font-size: 10px; border: 1px solid black"><?php echo e($n->deskripsi); ?></td>
            <td style="font-size: 10px; border: 1px solid black; text-align: right;"><?php echo e(number_format($n->debit, 2, ',', '.')); ?></td>
            <td style="font-size: 10px; border: 1px solid black; text-align: right;"><?php echo e(number_format($n->kredit, 2, ',', '.')); ?></td>
            <td style="font-size: 10px; border: 1px solid black"><?php echo e($n->formattanggal()); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr style="border: 1px solid black;">
            <td></td>
            <td></td>
            <td style="font-size: 12px;">Total (Rp)</td>
            <td style="border: 1px solid black; font-size: 12px; text-align: right;">
                    <?php echo e(number_format($sumdebit, 2, ',', '.')); ?>

            </td>
            <td style="border: 1px solid black; font-size: 12px; text-align: right;">
                    <?php echo e(number_format($sumkredit, 2, ',', '.')); ?>

            </td>
            <td></td>
        </tr>
        <tr style="border: 1px solid black;">
            <td></td>
            <td></td>
            <td style="font-size: 12px;">Saldo (Rp)</td>
            <td></td>
            <td></td>
            <?php if($balance > 0 ): ?>
            <td style="border: 1px solid black; background-color: green; color: white; font-size: 12px; text-align: right;">
                    <?php echo e(number_format($balance, 2, ',', '.')); ?>

            </td>
            <?php elseif($balance <= 0): ?>
            <td style="border: 1px solid black; background-color: red; color: white; font-size: 12px; text-align: right;">
                    <?php echo e(number_format($balance, 2, ',', '.')); ?>

            </td>
            <?php endif; ?>
        </tr>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\buttler\resources\views/export/neraca/neracapdf.blade.php ENDPATH**/ ?>