<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard.active'); ?>
active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
      <h1>Dahshboard</h1>
      <div class="section-header-breadcrumb">
        <div class="breadcrumb-item active"><a href="<?php echo e(route('pegawai.index')); ?>">Menu Dashboard</a></div>
        <div class="breadcrumb-item">Dashboard</div>
      </div>
    </div>

    <div class="section-body">
        
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-primary card-statistic-1">
                    <div class="card-icon bg-primary text-white">
                        <h2 class="mt-3">
                            
                            <?php echo e(date('d', strtotime($today))); ?>

                            <span><h6><?php echo e(date('M Y', strtotime($today))); ?></h6></span>

                        </h2>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            Update terakhir
                        </div>
                        <div class="card-body">
                            <?php echo e($sumneraca); ?> Transaksi
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-success card-statistic-1">
                    <div class="card-icon bg-success text-white">
                        <h2 class="mt-3">
                            <i class="fas fa-plus"></i>
                        </h2>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            Total Debit
                        </div>
                        <div class="card-body">
                            Rp <?php echo e(number_format($sumdebit, 2, ',', '.')); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-danger card-statistic-1">
                    <div class="card-icon bg-danger text-white">
                        <h2 class="mt-3">
                            <i class="fas fa-minus"></i>
                        </h2>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            Total Kredit
                        </div>
                        <div class="card-body">
                            Rp <?php echo e(number_format($sumkredit, 2, ',', '.')); ?>

                        </div>
                    </div>
                </div>
            </div>

            <?php if( $balance > 0 ): ?>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-success card-statistic-1">
                        <div class="card-icon bg-success text-white">
                            <h2 class="mt-3">
                                <i class="fas fa-chevron-up"></i>
                            </h2>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                Saldo
                            </div>
                            <div class="card-body text-success">
                                Rp <?php echo e(number_format($balance, 2, ',', '.')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-danger card-statistic-1">
                        <div class="card-icon bg-danger text-white">
                            <h2 class="mt-3">
                                <i class="fas fa-chevron-down"></i>
                            </h2>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                Saldo
                            </div>
                            <div class="card-body text-danger">
                                Rp <?php echo e(number_format($balance, 2, ',', '.')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-success card-statistic-1">
                    <div class="card-icon bg-success text-white">
                        <h2 class="mt-3">
                            <?php echo e($jml_s1); ?> <span><h6>Orang</h6></span>
                        </h2>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">

                        </div>
                        <div class="card-body">
                            Jumlah Pegawai Sektor 1
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-success card-statistic-1">
                    <div class="card-icon bg-success text-white">
                        <h2 class="mt-3">
                            <?php echo e($jml_s2); ?> <span><h6>Orang</h6></span>
                        </h2>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">

                        </div>
                        <div class="card-body">
                            Jumlah Pegawai Sektor 2
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-success card-statistic-1">
                    <div class="card-icon bg-success text-white">
                        <h2 class="mt-3">
                            <?php echo e($jml_s3); ?> <span><h6>Orang</h6></span>
                        </h2>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">

                        </div>
                        <div class="card-body">
                            Jumlah Pegawai Sektor 3
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-success card-statistic-1">
                    <div class="card-icon bg-success text-white">
                        <h2 class="mt-3">
                            <?php echo e($jml_s4); ?> <span><h6>Orang</h6></span>
                        </h2>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">

                        </div>
                        <div class="card-body">
                            Jumlah Pegawai Sektor 4
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-primary">
                    <i class="far fa-user"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Belum Hadir</h4>
                        </div>
                        <div class="card-body mb-5">
                            <?php echo e($belum_hadir); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-success">
                    <i class="far fa-user"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Sudah Hadir</h4>
                        </div>
                        <div class="card-body mb-5">
                            <?php echo e($jml_hadir); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-danger">
                    <i class="far fa-user"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Absen/Bolos</h4>
                        </div>
                        <div class="card-body mb-5">
                            <?php echo e($jml_bolos); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-warning">
                    <i class="far fa-user"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Izin/Cuti/Sakit</h4>
                        </div>
                        <div class="card-body mb-5">
                            <?php echo e($izin); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="row">
            <div class="col-12 col-md-6 col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h4>Grafik Neraca</h4>
                    </div>
                    <div class="card-body">
                        <div id="neracaChart">

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h4>Grafik Presensi</h4>
                    </div>
                    <div class="card-body">
                        <div id="presensiChart">

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="https://code.highcharts.com/highcharts.src.js"></script>
<script>
    Highcharts.chart('neracaChart', {
    chart: {
        type: 'spline'
    },
    title: {
        text: 'Grafik Saldo Bulanan'
    },
    subtitle: {
        text: 'Data Tahun 2021'
    },
    xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    },
    yAxis: {
        title: {
            text: 'Jumlah (Dalam Rupiah)'
        },
        labels: {
            formatter: function () {
                return 'Rp' + this.value ;
            }
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">Bulan {point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>Rp {point.y:.f},00</b></td></tr>',
        footerFormat: '</table>',
        crosshairs: true,
        shared: true,
        useHTML: true
    },
    plotOptions: {
        spline: {
            marker: {
                radius: 4,
                lineColor: '#666666',
                lineWidth: 1
            }
        }
    },
    series: [{
        name: 'Saldo',
        color: '#6777EF',
        marker: {
            symbol: 'square'
        },
        data: <?php echo json_encode($databalance); ?>


    }, {
        name: 'Debit',
        color: '#47C363',
        marker: {
            symbol: 'diamond'
        },
        data: <?php echo json_encode($datadebit); ?>

    }, {
        name: 'Kredit',
        color: '#FC544B',
        marker: {
            symbol: 'diamond'
        },
        data: <?php echo json_encode($datakredit); ?>

    }]
    });

    Highcharts.chart('presensiChart', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Grafik Presensi Pegawai 7 Hari Terakhir'
    },
    xAxis: {
        categories: <?php echo json_encode($categories); ?>,
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah Pegawai (orang)'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.f} orang</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Hadir',
        color: '#47C363',
        data: <?php echo json_encode($data1); ?>


    }, {
        name: 'Bolos',
        color: '#FC544B',
        data: <?php echo json_encode($data2); ?>


    }, {
        name: 'Cuti',
        color: '#6777EF',
        data: <?php echo json_encode($data3); ?>


    }, {
        name: 'Sakit',
        color: '#F67A3D',
        data: <?php echo json_encode($data4); ?>


    }, {
        name: 'Izin',
        color: '#FFB44C',
        data: <?php echo json_encode($data5); ?>


    },
    ]
    });


</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <script>
        swal("Good job!", "You clicked the button!", "success");
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/dashboard/index.blade.php ENDPATH**/ ?>