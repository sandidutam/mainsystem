<?php $__env->startSection('title'); ?>
    Menu Inventori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Detail Barang <?php echo e($stok_barang->nama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('inventori.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inventoriindex.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Barang - <?php echo e($stok_barang->nama); ?></h1>
            <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('inventori.index')); ?>">Menu Inventori</a></div>
            <div class="breadcrumb-item">Detail Barang</div>
      </div>
        </div>

        <div class="section-body">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <a href="<?php echo e(route('inventori.index')); ?>" class="btn btn-danger ">
                    <span class="icon">
                        <i class="fas fa-chevron-left mr-2"></i>
                    </span>
                    <span class="text">Kembali</span>
                </a>
            </div>

            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Detail Barang <?php echo e($stok_barang->nama); ?></h6>
                        </div>

                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 text-center card-split">
                                    <img class="img" style="margin-top: 50px; margin-bottom: 25px; width:250px; height:250px" src="<?php echo e($stok_barang->getGambarBarang()); ?>" alt="">
                                    <h3 class="mt-2 mb-2"><strong><?php echo e($stok_barang->nama); ?></strong></h3>
                                    <p class="mt-2" ><?php echo e($stok_barang->jenis); ?></p>

                                </div>
                                <div class="col">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                                            <tr>
                                                <td>Nama </td><td><?php echo e($stok_barang->nama); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Merk</td><td><?php echo e($stok_barang->merk); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Jenis</td><td><?php echo e($stok_barang->jenis); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Deskripsi</td><td><?php echo e($stok_barang->deskripsi); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Kuantitas</td><td><?php echo e($stok_barang->kuantitas); ?> <?php echo e($stok_barang->satuan); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Harga Satuan</td><td> Rp <?php echo e(number_format($stok_barang->harga, 2, ',', '.')); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Update Terakhir</td><td><?php echo e($stok_barang->updated_at->format('d-m-Y')); ?></a></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/inventori/detail.blade.php ENDPATH**/ ?>