<?php $__env->startSection('title'); ?>
    Menu User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Index User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('userindex.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Index User</h1>
        <a href="<?php echo e(route('user.create')); ?>" class="d-none d-sm-inline-block btn btn-md btn-primary shadow-sm ml-4">
            <i class="fas fa-plus-circle fa-sm text-white-50 mr-2"></i>Buat User Baru</a>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('user.index')); ?>">Menu User</a></div>
            <div class="breadcrumb-item">Index User</div>
        </div>
    </div>

    <div class="section-body">
      <!-- Page Heading -->
        

      <div class="card">
        

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="table-1" width="100%" cellspacing="0">
                <thead hidden>
                    <tr>
                        <th>Avatar</th>
                        <th>Nama Lengkap</th>
                        <th>Nomor Pegawai</th>
                        <th>Jabatan</th>
                        <th>Role</th>
                        <?php if(auth()->user()->role == "SuperAdmin" || auth()->user()->role == "Admin" ): ?>
                        <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('user.show', Crypt::encryptString($user->id))); ?>">
                                <img class="img" style="margin-right: 0px; margin-left: 60px; height: 75px; width: 75px; border-radius: 100%; border: 3px solid #6777EF; object-fit: cover;" src="<?php echo e($user->getFotoUser()); ?>" alt="">
                            </a>
                        </td>
                        <td>
                            <div class="mt-2">
                                <div class="row">
                                    <a style="color: black;" href="<?php echo e(route('user.show', Crypt::encryptString($user->id))); ?>">
                                        <h4>
                                            <?php echo e($user->nama_lengkap()); ?>

                                        </h4>
                                    </a>
                                </div>
                                
                            </div>
                        </td>
                        <td>
                            <div class="mt-4">
                                <h5>
                                    <span class="badge text-white" style="margin-left: 20px; background-color: #161b17">
                                        #<?php echo e($user->nomor_pegawai); ?>

                                    </span>
                                </h5>
                            </div>
                        </td>
                        <td>
                            <div class="mt-4">
                                <h5>
                                    <span class="badge text-white" style="margin-left: 20px; background-color: #6777EF;">
                                        <?php echo e($user->jabatan); ?>

                                    </span>
                                </h5>
                            </div>
                        </td>
                        <td>
                            <div class="mt-4">
                                <h5>
                                    <span class="badge text-white" style="margin-left: 20px; background-color: #6777EF;">
                                        <?php echo e($user->role); ?>

                                    </span>
                                </h5>
                            </div>
                        </td>
                        <?php if(auth()->user()->role == "SuperAdmin"): ?>
                            <td>
                                <div class="row mt-2">
                                

                                

                                <button class="btn btn-md btn-danger m-2 delete" id_user="<?php echo e(Crypt::encryptString($user->id)); ?>" nama_lengkap="<?php echo e($user->nama_lengkap()); ?>">
                                    <i class="fas fa-trash mr-2"></i> Hapus
                                </button>

                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </tbody>
                </table>
            </div>

        </div>
      </div>
    </div>
</section>

<script>
        $('.delete').click(function() {
        var id = $(this).attr('id_user');
        var nama_lengkap = $(this).attr('nama_lengkap');
        swal({
            title: 'Ingin menghapus data '+nama_lengkap+' ??',
            text: 'Langkah ini akan menghapus data '+nama_lengkap+' secara permanen.',
            icon: 'warning',
            buttons: true,
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                window.location = "/user/"+id+"/destroy";
            }
            });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/users/index.blade.php ENDPATH**/ ?>