

<?php $__env->startSection('title'); ?>
    Menu Inventori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Update Inventori - <?php echo e($stok_barang->nama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('inventori.active'); ?>
active
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('inventoriindex.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Update Inventori - <?php echo e($stok_barang->nama); ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('inventori.index')); ?>">Menu Inventori</a></div>
                <div class="breadcrumb-item">Update Inventori</div>
            </div>
        </div>    
    
        <div class="section-body">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <a href="<?php echo e(route('inventori.index')); ?>" class="d-none d-sm-inline-block btn btn-md btn-primary shadow-sm">
                <i class="fas fa-chevron-left mr-2"></i> Kembali</a>
            </div>

            <div class="row d-flex justify-content-center">
                <div class="card" >
                    <div class="card-header">
                        <h4 class="m-0 font-weight-bold text-primary">Form Update Data Barang - <?php echo e($stok_barang->nama); ?></h4>
                    </div>
                
                    <div class="card-body">
                        <?php echo Form::model($stok_barang ,['route'=>['inventori.update', $stok_barang->id], 'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

        
                            <div class="row">
                                <div class="col">
                                    <div class="row">
                                        <div class="col-12 col-md-6 col-lg-6">
                                            <div class="form-group">
                                                <label for="nama" class="form-label"> Nama Barang : </label> 
                                                <?php echo Form::text('nama', null, ['class'=>'form-control','id'=>'nama']); ?>

                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-6">
                                            <div class="form-group">
                                                <label for="merk" class="form-label"> Merk : </label> 
                                                <?php echo Form::text('merk', null, ['class'=>'form-control','id'=>'merk']); ?>

                                            </div>
                                        </div>
                                    </div>
            
                                    <div class="form-group <?php echo e($errors->has('jenis') ? 'has-error' : ''); ?> "> 
                                        <label for="jenis" class="form-label"> Jenis : </label> 
                                        <?php echo Form::text('jenis', null, ['class'=>'form-control','id'=>'jenis']); ?>

                                    </div>
                                    
                                    <div class="form-group <?php echo e($errors->has('deskripsi') ? 'has-error' : ''); ?> ">
                                        <label for="deskripsi"> Deskripsi : </label>
                                        <?php echo Form::textarea('deskripsi', null, ['class'=>'form-control','id'=>'deskripsi']); ?>

                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-12 col-md-6 col-lg-6">
                                            <div class="form-group <?php echo e($errors->has('kuantitas') ? 'has-error' : ''); ?> "> 
                                                <label for="kuantitas" class="form-label"> Kuantitas : </label> 
                                                <?php echo Form::number('kuantitas', null, ['class'=>'form-control','id'=>'kuantitas']); ?>

                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-6">
                                            <div class="form-group ">
                                                <label for="satuan" > Satuan : </label>
                                                <select name="satuan" class="form-control" id="satuan" >
                                                    <option>Pilih</option>
                                                    <option value="pcs" <?php echo e((old('satuan',$stok_barang->satuan)=='pcs')? 'selected' :''); ?>>pcs</option>
                                                    <option value="cc" <?php echo e((old('satuan',$stok_barang->satuan)=='cc')? 'selected' :''); ?>>cc</option>
                                                    <option value="ml" <?php echo e((old('satuan',$stok_barang->satuan)=='ml')? 'selected' :''); ?>>mililiter</option>
                                                    <option value="liter" <?php echo e((old('satuan',$stok_barang->satuan)=='liter')? 'selected' :''); ?>>liter</option>
                                                    <option value="gr" <?php echo e((old('satuan',$stok_barang->satuan)=='gr')? 'selected' :''); ?>>gram</option>
                                                    <option value="Kg" <?php echo e((old('satuan',$stok_barang->satuan)=='Kg')? 'selected' :''); ?>>kilogram</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
    
                                    <div class="form-group <?php echo e($errors->has('kuantitas') ? 'has-error' : ''); ?> "> 
                                        <label for="stok_minimal" class="form-label">Jumlah Stok Minimal : </label> 
                                        <?php echo Form::number('stok_minimal', null, ['class'=>'form-control','id'=>'stok_minimal']); ?>

                                    </div>
    
                                    <div class="form-group <?php echo e($errors->has('harga') ? 'has-error' : ''); ?> "> 
                                        <label for="harga" class="form-label"> Harga : </label> 
                                        <?php echo Form::number('harga', null, ['class'=>'form-control','id'=>'harga']); ?>

                                    </div>
    
                                    <div class="form-group <?php echo e($errors->has('gambar') ? 'has-error' : ''); ?> "> 
                                        <div class="mb-3">
                                            <label for="gambar" class="form-label">Unggah Gambar Barang:</label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" name="gambar" id="gambar" value="<?php echo e(old('gambar')); ?>">
                                                <label class="custom-file-label" for="customFile">Choose file</label>
                                            </div>
                                            <?php if($errors->has('gambar')): ?>
                                                <span class="help-block text-danger"><?php echo e($errors->first('gambar')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>   
                                </div>
    
                                
                                
                            </div>
                            <div class="d-flex justify-content-start mb-3 ">
                                <div class="row">
                                    <div class="col">
                                        <a href="<?php echo e(route('inventori.index')); ?>" class="btn btn-danger" role="button">Batal</a>
                                    </div>
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            
                    <?php echo Form::close(); ?>




        </div>

    </section>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/inventori/edit.blade.php ENDPATH**/ ?>