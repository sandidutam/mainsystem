<h1>Data Presensi</h1>

<table class="table">
    <thead>
        <tr style="background-color: black; color: white;">
            <th>Tanggal</th>
            <th>Nomor Pegawai</th>
            <th>Nama Lengkap</th>
            <th>Sektor</th>
            <th>Jam Masuk</th>
            <th>Jam Keluar</th>
            
            <th>Ket</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $presensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(date('d F Y', strtotime($p->tanggal))); ?></td>
            <td><?php echo e($p->pegawai->nomor_pegawai); ?></td>
            <td><?php echo e($p->pegawai->nama_lengkap()); ?></td>
            <td><?php echo e($p->pegawai->sektor_area); ?></td>
            <td><?php echo e($p->jam_masuk); ?></td>
            <td><?php echo e($p->jam_keluar); ?></td>
            
            <td><?php echo e($p->keterangan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\buttler\resources\views/export/presensi/presensipdf.blade.php ENDPATH**/ ?>