<?php $__env->startSection('title'); ?>
    Menu Neraca
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Detail Transaksi <?php echo e($neraca->akun); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('neraca.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('neracaindex.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1> Detail Transaksi <?php echo e($neraca->akun); ?></h1>
            <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('neraca.index')); ?>">Menu Neraca</a></div>
            <div class="breadcrumb-item">Detail Neraca</div>
      </div>
        </div>

        <div class="section-body">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <a href="<?php echo e(route('neraca.index')); ?>" class="btn btn-danger ">
                    <span class="icon">
                        <i class="fas fa-chevron-left mr-2"></i>
                    </span>
                    <span class="text">Kembali</span>
                </a>
            </div>

            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"> Detail Transaksi <?php echo e($neraca->akun); ?></h6>
                        </div>

                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 text-center card-split">
                                    
                                    <h3 class="mt-2 mb-2"><strong><?php echo e($neraca->akun); ?></strong></h3>
                                    <p class="mt-2" ><?php echo e($neraca->deskripsi); ?></p>

                                </div>
                                <div class="col">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                                            <tr>
                                                <td>Nomor Transaksi </td><td><?php echo e($neraca->nomor_akun); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Transaksi </td><td><?php echo e($neraca->akun); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td>Deskripsi</td><td><?php echo e($neraca->deskripsi); ?></a></td>
                                            </tr>
                                            <?php if($neraca->debit != null && $neraca->kredit == null): ?>
                                            <tr>
                                                <td>Jenis</td><td class="text-success"><strong>Debit</strong></a></td>
                                            </tr>
                                            <?php elseif($neraca-> kredit != null && $neraca->debit == null ): ?>
                                            <tr>
                                                <td>Jenis</td><td class="text-danger"><strong>Kredit</strong></a></td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <td>Tanggal</td><td><?php echo e(date('d F Y', strtotime($neraca->tanggal))); ?></a></td>

                                            </tr>

                                            <tr>
                                                <td>Update Terakhir</td><td><?php echo e($neraca->updated_at->format('d-m-Y')); ?></a></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/neraca/detail.blade.php ENDPATH**/ ?>