<?php $__env->startSection('title'); ?>
    Menu Inventori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Index Inventori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inventori.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inventoriindex.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
      <h1>Index Inventori</h1>
      <div class="section-header-breadcrumb">
          <div class="breadcrumb-item active"><a href="<?php echo e(route('inventori.index')); ?>">Menu Inventori</a></div>
          <div class="breadcrumb-item">Index Inventori</div>
      </div>
    </div>

    <div class="section-body">

        <!-- Page Heading -->
        <?php if(auth()->user()->role == "SuperAdmin" | auth()->user()->role == "Admin"): ?>
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <a href="<?php echo e(route('inventori.create')); ?>" class="d-none d-sm-inline-block btn btn-md btn-primary shadow-sm">
              <i class="fas fa-plus-circle fa-sm text-white-50 mr-2"></i> Data Baru</a>
          </div>
        <?php endif; ?>

        <div class="card">
          <div class="card-header">
            <h4>Data Inventori</h4>
          </div>

          

          <?php if(session('notifikasi_sukses')): ?>
            <div class="alert alert-success alert-dismissible m-3 show fade" role="alert">
              <div class="alert-body">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <i class="fas fa-check"></i>
                <?php echo e(session('notifikasi_sukses')); ?>

              </div>
            </div>
          <?php endif; ?>

          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover table-striped" id="table-1" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Gambar</th>
                    <th>Nama</th>
                    <th>Merk</th>
                    <th>Qty</th>
                    <th>Harga Satuan</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                    <th>Update Terakhir</th>
                    <?php if(auth()->user()->role == "SuperAdmin" | auth()->user()->role == "Admin"): ?>
                    <th>Aksi</th>
                    <?php endif; ?>
                  </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $stok_barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr >
                        <td><?= $i; ?></td>
                        <td><a href="<?php echo e(route('inventori.detail', Crypt::encryptString($barang->id))); ?>"><img class="img" style="height: 75px; width:75px" src="<?php echo e($barang->getGambarBarang()); ?>" alt=""></a></td>
                        <?php if($barang->status == 'Aman'): ?>

                            <td><a href="<?php echo e(route('inventori.detail', Crypt::encryptString($barang->id))); ?>"><?php echo e($barang->nama); ?> <i class="fas fa-check" style="color: #47C363;"></i></a></td>

                        <?php elseif($barang->status == 'Tidak Aman'): ?>

                            <td><a href="<?php echo e(route('inventori.detail', Crypt::encryptString($barang->id))); ?>"><?php echo e($barang->nama); ?> <i class="fas fa-exclamation-triangle" style="color: #FFA426;"></i></a></td>

                        <?php elseif($barang->status == 'Habis'): ?>

                            <td><a href="<?php echo e(route('inventori.detail', Crypt::encryptString($barang->id))); ?>"><?php echo e($barang->nama); ?> <i class="fas fa-exclamation" style="color: #FC544B;"></i></a></td>

                        <?php endif; ?>

                        <td><?php echo e($barang->merk); ?></td>
                        <td><?php echo e($barang->kuantitas); ?> <?php echo e($barang->satuan); ?></td>
                        <td>Rp <?php echo e(number_format($barang->harga, 2, ',', '.')); ?></td>
                        <td>Rp <?php echo e(number_format(($barang->kuantitas)*($barang->harga), 2, ',', '.' )); ?></td>
                        <?php if($barang->status == 'Aman'): ?>

                            <td class="text-white" style="background-color: green"><h6>Stok Aman</h6></td>

                        <?php elseif($barang->status == 'Tidak Aman'): ?>

                            <td class="text-white" style="background-color: orange"><h6>Stok Tinggal Sedikit</h6></td>

                        <?php elseif($barang->status == 'Habis'): ?>

                            <td class="text-white" style="background-color: red"><h6>Stok Habis</h6></td>

                        <?php endif; ?>

                        <td>
                              Jam : <?php echo e($barang->updated_at->format('H:i')); ?> <br>
                              Tanggal : <?php echo e($barang->updated_at->format('d-m-Y')); ?>

                        </td>
                        <?php if(auth()->user()->role == "SuperAdmin" | auth()->user()->role == "Admin"): ?>
                        <td>
                            <div class="row">
                                <a href="<?php echo e(route('inventori.edit', Crypt::encryptString($barang->id))); ?>" class="btn btn-md btn-warning m-2" type="button"><i class="fas fa-edit mr-1"></i> Update</a>
                                <button class="btn btn-md btn-danger m-2 delete" id_barang="<?php echo e(Crypt::encryptString($barang->id)); ?>" nama="<?php echo e($barang->nama); ?>">
                                    <i class="fas fa-trash mr-2"></i> Hapus
                                </button>
                                
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                    <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</section>

<script>
     $('.delete').click(function() {
        var id = $(this).attr('id_barang');
        var nama = $(this).attr('nama');
        swal({
            title: 'Ingin menghapus data '+nama+' ??',
            text: 'Langkah ini akan menghapus data '+nama+' secara permanen.',
            icon: 'warning',
            buttons: true,
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                window.location = "/inventori/"+id+"/destroy";
            }
            });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/inventori/index.blade.php ENDPATH**/ ?>