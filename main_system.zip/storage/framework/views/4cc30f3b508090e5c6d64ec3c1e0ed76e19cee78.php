<form class="form-inline mr-auto">
    <ul class="navbar-nav mr-3">
      <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
      
    </ul>
    
  </form>
  <ul class="navbar-nav navbar-right">
    
    <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
      <figure class="avatar avatar-sm mr-2">
        <img src="<?php echo e((auth()->user()->getFotoUser())); ?>" alt="...">
      </figure>
      
      <?php if( auth()->user()->role == "SuperAdmin" ): ?>
      <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(auth()->user()->nama_lengkap()); ?> <i class="fas fa-crown" style="color: gold"></i> </div></a>
      <?php else: ?>
      <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(auth()->user()->nama_lengkap()); ?> </div></a>
      <?php endif; ?>
      <div class="dropdown-menu dropdown-menu-right">
        <div class="dropdown-title">
            
            <div hidden>
                <?php echo e($today = \Carbon\Carbon::now()->timezone('Asia/Jakarta')->format('H:i:s')); ?>

                <?php echo e($diff = \Carbon\Carbon::parse(auth()->user()->last_login_at)->diffInHours($today)); ?>

            </div>
            Logged in
            <?php if( $diff == 0 ): ?>

            <?php elseif(  $diff != 0 ): ?>
            <?php echo e(\Carbon\Carbon::parse(auth()->user()->last_login_at)->diffInHours($today)); ?> jam
            <?php endif; ?>
            <?php echo e(\Carbon\Carbon::parse(auth()->user()->last_login_at)->diff($today)->i); ?> menit yang lalu.

            
        </div>
        <a href="<?php echo e(route('user.show', Crypt::encryptString(auth()->user()->id))); ?>" class="dropdown-item has-icon">
          <i class="far fa-user"></i> Profile
        </a>
        
        <div class="dropdown-divider"></div>
        <a href="/logout" class="dropdown-item has-icon text-danger">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
    </li>
  </ul>
<?php /**PATH C:\laragon\www\buttler\resources\views/layouts/topnav.blade.php ENDPATH**/ ?>