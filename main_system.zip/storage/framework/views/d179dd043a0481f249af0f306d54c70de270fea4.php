<?php $__env->startSection('title'); ?>
    Menu Presensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Linimasa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('presensi.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('presensiactivity.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Linimasa</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Menu Presensi</a></div>
                <div class="breadcrumb-item">Linimasa</div>
            </div>
        </div>

        <div class="section-body">
            <div class="section-title mt-1 mb-4"><h5><?php echo e(date('d F Y', strtotime($hari_ini))); ?>, <span id="currentTime" style="font-size: 18px; margin: 0; color: green;"></span></h5></div>

            <div class="row align-items-top justify-content-start">
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="card chat-box" id="mychatbox" style="height : 600px;">
                        <div class="card-header">
                            <h4>Aktifitas Hari Ini</h4>
                        </div>
                        <div class="card-body chat-content">
                            <div class="row">
                                <div class="col-12">
                                    <div class="activities" style="font-size : 18px;">
                                        <h6><?php echo e(date('d F Y', strtotime($hari_ini))); ?></h6>
                                        <?php $__currentLoopData = $data_hari_ini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->keterangan == 'Hadir' && $item->catatan_masuk == !null && $item->catatan_keluar == null): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-success text-white shadow-primary">
                                                        <i class="fas fa-sign-in-alt"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-success" style="font-size : 14px;" href="#">Masuk</a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #47C363; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> sudah masuk ke kantor.</p>
                                                    </div>
                                                </div>
                                            <?php elseif($item->keterangan == 'Hadir' && $item->catatan_masuk == !null && $item->catatan_keluar == !null): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-primary text-white shadow-primary">
                                                        <i class="fas fa-check"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-primary" style="font-size : 14px;" href="#">Shift Selesai</a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #6777EF; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;">
                                                            <a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> masuk pada jam <span class="text-success"><?php echo e(date('H:i', strtotime($item->jam_masuk))); ?></span> dan pulang pada jam <span class="text-success"><?php echo e(date('H:i', strtotime($item->jam_keluar))); ?></span>.
                                                            Dia bekerja selama <?php echo e(\Carbon\Carbon::parse($item->created_at)->diffInHours($item->updated_at)); ?> jam <?php echo e(\Carbon\Carbon::parse($item->created_at)->diff($item->updated_at)->i); ?> menit.
                                                        </p>
                                                    </div>
                                                </div>
                                            <?php elseif($item->keterangan == 'Bolos'): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-danger text-white shadow-primary">
                                                        <i class="fas fa-thumbtack"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-danger" style="font-size : 14px;" href="#"><?php echo e($item->keterangan); ?></a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #FC544B; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> hari ini bolos.</p>
                                                    </div>
                                                </div>
                                            <?php elseif($item->keterangan != 'Bolos' && $item->catatan_masuk == "-"): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-warning text-white shadow-primary">
                                                        <i class="fas fa-thumbtack"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-danger" style="font-size : 14px;" href="#"><?php echo e($item->keterangan); ?></a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #FFA426; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> hari ini <?php echo e($item->keterangan); ?>.</p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="card chat-box" id="mychatbox"  style="height : 600px;">
                        <div class="card-header">
                            <h4>Aktifitas Kemarin</h4>
                        </div>
                        <div class="card-body chat-content" style="background-color: green;">
                            <div class="row">
                                <div class="col-12">
                                    <div class="activities" style="font-size : 18px;">
                                        <h6><?php echo e(date('d F Y', strtotime($kemarin))); ?></h6>
                                        <?php $__currentLoopData = $data_kemarin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->keterangan == 'Hadir' && $item->catatan_masuk == !null && $item->catatan_keluar == null): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-success text-white shadow-primary">
                                                        <i class="fas fa-sign-in-alt"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-success" style="font-size : 14px;" href="#">Masuk</a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #47C363; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> sudah masuk ke kantor.</p>
                                                    </div>
                                                </div>
                                            <?php elseif($item->keterangan == 'Hadir' && $item->catatan_masuk == !null && $item->catatan_keluar == !null): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-primary text-white shadow-primary">
                                                        <i class="fas fa-check"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-primary" style="font-size : 14px;" href="#">Shift Selesai</a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #6777EF; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;">
                                                            <a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> masuk pada jam <span class="text-success"><?php echo e(date('H:i', strtotime($item->jam_masuk))); ?></span> dan pulang pada jam <span class="text-success"><?php echo e(date('H:i', strtotime($item->jam_keluar))); ?></span>.
                                                            Dia bekerja selama <?php echo e(\Carbon\Carbon::parse($item->created_at)->diffInHours($item->updated_at)); ?> jam <?php echo e(\Carbon\Carbon::parse($item->created_at)->diff($item->updated_at)->i); ?> menit.
                                                        </p>
                                                    </div>
                                                </div>
                                            <?php elseif($item->keterangan == 'Bolos'): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-danger text-white shadow-primary">
                                                        <i class="fas fa-thumbtack"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-danger" style="font-size : 14px;" href="#"><?php echo e($item->keterangan); ?></a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #FC544B; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> hari ini bolos.</p>
                                                    </div>
                                                </div>
                                            <?php elseif($item->keterangan != 'Bolos' && $item->catatan_masuk == "-"): ?>
                                                <div class="activity">
                                                    <div class="activity-icon bg-warning text-white shadow-primary">
                                                        <i class="fas fa-thumbtack"></i>
                                                    </div>
                                                    <div class="activity-detail">
                                                        <div class="mb-2">
                                                            <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                            <span class="bullet"></span>
                                                            <a class="text-job text-danger" style="font-size : 14px;" href="#"><?php echo e($item->keterangan); ?></a>
                                                        </div>
                                                        <div class="row d-flex justify-content-center">
                                                            <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #FFA426; object-fit: cover;">
                                                        </div>
                                                        <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> hari ini <?php echo e($item->keterangan); ?>.</p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="card chat-box" id="mychatbox"  style="height : 600px;">
                        <div class="card-header">
                            <h4>Riwayat Seluruhnya</h4>
                        </div>
                        <div class="card-body chat-content">
                            <div class="row">
                                <div class="col-12">
                                    <div class="activities" style="font-size : 18px;">
                                        <?php $__currentLoopData = $data_presensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari => $hari_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <h6><?php echo e($hari); ?></h6>
                                            <?php $__currentLoopData = $hari_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->keterangan == 'Hadir' && $item->catatan_masuk == !null && $item->catatan_keluar == null): ?>
                                                    <div class="activity">
                                                        <div class="activity-icon bg-success text-white shadow-primary">
                                                            <i class="fas fa-sign-in-alt"></i>
                                                        </div>
                                                        <div class="activity-detail">
                                                            <div class="mb-2">
                                                                <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                                <span class="bullet"></span>
                                                                <a class="text-job text-success" style="font-size : 14px;" href="#">Masuk</a>
                                                            </div>
                                                            <div class="row d-flex justify-content-center">
                                                                <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #47C363; object-fit: cover;">
                                                            </div>
                                                            <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> sudah masuk ke kantor.</p>
                                                        </div>
                                                    </div>
                                                <?php elseif($item->keterangan == 'Hadir' && $item->catatan_masuk == !null && $item->catatan_keluar == !null): ?>
                                                    <div class="activity">
                                                        <div class="activity-icon bg-primary text-white shadow-primary">
                                                            <i class="fas fa-check"></i>
                                                        </div>
                                                        <div class="activity-detail">
                                                            <div class="mb-2">
                                                                <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                                <span class="bullet"></span>
                                                                <a class="text-job text-primary" style="font-size : 14px;" href="#">Shift Selesai</a>
                                                            </div>
                                                            <div class="row d-flex justify-content-center">
                                                                <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #6777EF; object-fit: cover;">
                                                            </div>
                                                            <p style="font-weight: bold;">
                                                                <a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> masuk pada jam <span class="text-success"><?php echo e(date('H:i', strtotime($item->jam_masuk))); ?></span> dan pulang pada jam <span class="text-success"><?php echo e(date('H:i', strtotime($item->jam_keluar))); ?></span>.

                                                                Dia bekerja selama <?php echo e(\Carbon\Carbon::parse($item->created_at)->diffInHours($item->updated_at)); ?> jam <?php echo e(\Carbon\Carbon::parse($item->created_at)->diff($item->updated_at)->i); ?> menit.
                                                            </p>

                                                        </div>
                                                    </div>
                                                <?php elseif($item->keterangan == 'Bolos'): ?>
                                                    <div class="activity">
                                                        <div class="activity-icon bg-danger text-white shadow-primary">
                                                            <i class="fas fa-thumbtack"></i>
                                                        </div>
                                                        <div class="activity-detail">
                                                            <div class="mb-2">
                                                                <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                                <span class="bullet"></span>
                                                                <a class="text-job text-danger" style="font-size : 14px;" href="#"><?php echo e($item->keterangan); ?></a>
                                                            </div>
                                                            <div class="row d-flex justify-content-center">
                                                                <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #FC544B; object-fit: cover;">
                                                            </div>
                                                            <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> hari ini bolos.</p>
                                                        </div>
                                                    </div>
                                                <?php elseif($item->keterangan != 'Bolos' && $item->catatan_masuk == "-"): ?>
                                                    <div class="activity">
                                                        <div class="activity-icon bg-warning text-white shadow-primary">
                                                            <i class="fas fa-thumbtack"></i>
                                                        </div>
                                                        <div class="activity-detail">
                                                            <div class="mb-2">
                                                                <span class="text-job text-primary" style="font-size : 14px;"><?php echo e(date('H:i', strtotime($item->updated_at))); ?></span>
                                                                <span class="bullet"></span>
                                                                <a class="text-job text-danger" style="font-size : 14px;" href="#"><?php echo e($item->keterangan); ?></a>
                                                            </div>
                                                            <div class="row d-flex justify-content-center">
                                                                <img src="<?php echo e($item->pegawai->getFotoPegawai()); ?>" style="height: 100px; width: 100px; border-radius: 100px; border: 2px solid #FFA426; object-fit: cover;">
                                                            </div>
                                                            <p style="font-weight: bold;"><a href="<?php echo e(route('pegawai.show', $item->pegawai_id)); ?>"><?php echo e($item->pegawai->nama_lengkap()); ?></a> hari ini <?php echo e($item->keterangan); ?>.</p>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/presensi/activity.blade.php ENDPATH**/ ?>