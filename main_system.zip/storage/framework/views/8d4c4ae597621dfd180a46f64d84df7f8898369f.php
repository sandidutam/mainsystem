<?php $__env->startSection('title'); ?>
    Menu Presensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-title'); ?>
    Presensi Masuk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('presensi.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('indexin.active'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="section">
        <div class="section-header">
            <h1>Menu Presensi Masuk</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('presensi.history')); ?>">Menu Presensi</a></div>
                <div class="breadcrumb-item">Presensi Masuk</div>
            </div>
        </div>

        <div class="section-body">
            <div class="card">
                <div class="card-header">
                    <h4>Menu Presensi Masuk</h4>
                </div>

                <div class="card-body">
                    <?php if(session('notifikasi_sukses')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <i class="fa fa-check-circle"></i>
                        <?php echo e(session('notifikasi_sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session('notifikasi_gagal')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <i class="fa fa-exclamation-triangle"></i>
                        <?php echo e(session('notifikasi_gagal')); ?>

                    </div>
                    <?php endif; ?>

                    

                    <div class="table-responsive">
                        <table class="table table-hover table-striped" id="table-1" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>NOMOR PEGAWAI</th>
                                    <th>NAMA LENGKAP</th>
                                    <th>JABATAN</th>
                                    <th>SEKTOR</th>
                                    <th>AKSI</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $data_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?php echo e($pegawai->nomor_pegawai); ?></td>
                                    <td><?php echo e($pegawai->nama_lengkap()); ?></td>
                                    <td><?php echo e($pegawai->jabatan); ?></td>
                                    <td><?php echo e($pegawai->sektor_area); ?></td>
                                    <td>
                                        <div class="row">
                                            <div class="col">
                                                <a href="<?php echo e(route('presensi.checkin', Crypt::encryptString($pegawai->id))); ?>" class="btn btn-md btn-success" type="button">Presensi Masuk</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\buttler\resources\views/presensi/indexIn.blade.php ENDPATH**/ ?>