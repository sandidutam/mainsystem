<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <h3 class="mt-4"><a href="<?php echo e(route('dashboard.index')); ?>">Main<span class="text-primary">2X</span></a></h3>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="index.html">M<span class="text-primary">2X</span></a>
    </div>
    <ul class="sidebar-menu">
        <li class="menu-header">Dashboard</li>
        <li class="<?php echo $__env->yieldContent('dashboard.active'); ?>"><a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>"><i class="fas fa-fire"></i> <span>Dashboard</span></a></li>

        
        <li class="menu-header">Menu</li>
        
        <li class="<?php echo $__env->yieldContent('pegawai.active'); ?>"><a class="nav-link" href="<?php echo e(route('pegawai.index')); ?>"><i class="fas fa-user-friends"></i> <span>Pegawai</span></a></li>

        
        <li class="nav-item dropdown <?php echo $__env->yieldContent('presensi.active'); ?>">
          <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-user-check"></i> <span>Presensi</span></a>
          <ul class="dropdown-menu">
            <li class="<?php echo $__env->yieldContent('presensiindex.active'); ?>"><a class="nav-link" href="<?php echo e(route('presensi.history')); ?>">Index</a></li>
            <li class="<?php echo $__env->yieldContent('presensiactivity.active'); ?>"><a class="nav-link" href="<?php echo e(route('presensi.activity')); ?>">Linimasa</a></li>
            <?php if(auth()->user()->role == "SuperAdmin" || auth()->user()->role == "Mandor" ): ?>
            <li class="<?php echo $__env->yieldContent('indexin.active'); ?>"><a class="nav-link" href="<?php echo e(route('presensi.indexin')); ?>">Presensi Masuk</a></li>
            <li class="<?php echo $__env->yieldContent('indexout.active'); ?>"><a class="nav-link" href="<?php echo e(route('presensi.indexout')); ?>">Presensi Keluar</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <li class="nav-item dropdown <?php echo $__env->yieldContent('inventori.active'); ?>">
          <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-warehouse"></i> <span>Inventori</span></a>
          <ul class="dropdown-menu">
            <li class="<?php echo $__env->yieldContent('inventoriindex.active'); ?>"><a class="nav-link" href="<?php echo e(route('inventori.index')); ?>">Index</a></li>
            <li class="<?php echo $__env->yieldContent('priceindex.active'); ?>"><a class="nav-link" href="<?php echo e(route('inventori.price')); ?>">Tabel Harga</a></li>
            <li class="<?php echo $__env->yieldContent('stokinventori.active'); ?>"><a class="nav-link" href="<?php echo e(route('inventori.stock')); ?>">Stok</a></li>
          </ul>
        </li>

        <?php if(auth()->user()->role == "SuperAdmin" | auth()->user()->role == "Akuntan" | auth()->user()->role == "Admin"): ?>
        <li class="<?php echo $__env->yieldContent('neraca.active'); ?>"><a class="nav-link" href="<?php echo e(route('neraca.index')); ?>"><i class="fas fa-book"></i> <span>Neraca Keuangan</span></a></li>
        <?php endif; ?>

        
        <li class="menu-header">User</li>
        <li class="<?php echo $__env->yieldContent('user.active'); ?>">
            <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <i class="fas fa-users"></i> <span>All User</span>
            </a>
        </li>

        <li class="<?php echo $__env->yieldContent('authuser.active'); ?>">
            <a class="nav-link" href="<?php echo e(route('user.show', Crypt::encryptString(auth()->user()->id))); ?>">
                <?php if( auth()->user()->role == "SuperAdmin" ): ?>
                <i class="fas fa-crown" style="color: #6777EF"></i>
                <?php else: ?>
                <i class="fas fa-user"></i>
                <?php endif; ?>
                <span style="font-weight: bold;"><?php echo e((auth()->user()->nama_lengkap())); ?></span>
            </a>
        </li>

      </ul>

      <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
        
      </div>
  </aside>
<?php /**PATH C:\laragon\www\buttler\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>